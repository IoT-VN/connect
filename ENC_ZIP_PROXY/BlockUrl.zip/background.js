chrome.webRequest.onBeforeRequest.addListener(
  info => {
    const host = (info.initiator || '').split('/', 3)[2];
    if (host === 'connect.appen.com') {
      return {cancel: true};
    }
  },
  {
    urls: [
      '*://*.recaptcha.net/*',
      '*://*.gstatic.com/*',
	  '*://*.connect.facebook.net/*',
	  '*://*.d35fpyi7wmbdba.cloudfront.net/*',
	  '*://*.googleads.g.doubleclick.net/*',
	  '*://*.facebook.com/*',
	  '*://*.googleadservices.com/*',
	  '*://*.googletagmanager.com/*',
	  '*://*.optimizationguide-pa.googleapis.com/*',
	  '*://*.cdn.mxpnl.com/*',
	  
    ],
  },
  ['blocking']
);